<?php
    if( $_GET["username"] || $_GET["message"] ) {
        $conn = new PDO("pgsql:host=db;port=5432;dbname=postgres;user=postgres;password=postgres;");

        $result = $conn->query("INSERT INTO Post(username, message) VALUES ('".$_GET['username']."', '".$_GET['message']."');");
        if (!$result) {
            echo "Error in insert.\n";
            exit;
        }
    }
    
?>

<html>
    <head></head>
    <body>
        <h1>Feed</h1>
        <?php
            $conn = new PDO("pgsql:host=db;port=5432;dbname=postgres;user=postgres;password=postgres;");

            // Query the database to check if the user exists
            $result = $conn->query("SELECT * FROM post LIMIT 1");
            if (!$result) {
                echo "An error occurred.\n";
                exit;
            }

            try {
                $fresult = $result->fetchAll(PDO::FETCH_ASSOC);
                foreach ($fresult as &$value){
                    echo "<p><b>".$value["username"]."</b>: ".$value["message"]."<p>";
                    echo "<hr/>";
                }
            }
            catch (PDOException $e) {
                echo $e->getMessage();
            }
        ?>
        <form action = "<?php $_PHP_SELF ?>" method = "GET">
            username: <input type = "text" name = "username" />
            message: <input type = "text" name = "message" />
            <input type = "submit" />
        </form>
    </body>
</html>