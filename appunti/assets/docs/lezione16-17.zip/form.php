<?php
   $name = $_GET["name"];
   $name = str_replace("script", "", $name);
   $name1 = htmlspecialchars($_GET["name"]);

   echo " name:".$name."<br>";
   echo " name1:".$name1."<br>";

   if( $name || $_GET["age"] ) {
      echo "Welcome ". $name1. "<br />";
      echo "You are ". $_GET['age']. " years old.";
      
      exit();
   }

?>
<html>
   <body>
   
      <form action = "<?php $_PHP_SELF ?>" method = "GET">
         Name: <input type = "text" name = "name" />
         Age: <input type = "text" name = "age" />
         <input type = "submit" />
      </form>
      
   </body>
</html>



