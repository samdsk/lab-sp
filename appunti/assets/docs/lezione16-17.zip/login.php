<html>
    <head></head>
    <body>
        <h1>Login</h1>

<?php

    $conn = new PDO("pgsql:host=db;port=5432;dbname=postgres;user=postgres;password=postgres;");

    // Handle login
    $username = $_GET["username"];
    $password = sha1($_GET["password"]."\n");

    // Query the database to check if the user exists
    $result = $conn->query("SELECT * FROM users WHERE username='$username' AND password='$password'");
    //echo "SELECT * FROM users WHERE username='$username' AND password='$password'";
    if (!$result) {
        echo "An error occurred.\n";
        exit;
    }

    try {
        $fresult = $result->fetchAll(PDO::FETCH_ASSOC);
        foreach ($fresult as &$value){
            echo "<h4>Welcome <b>".$value["username"]."</b></h4>";
            echo "<br/>";
        }
    }
    catch (PDOException $e) {
        echo $e->getMessage();
    }

?>
        <form action = "<?php $_PHP_SELF ?>" method = "GET">
            username: <input type = "text" name = "username" />
            password: <input type = "text" name = "password" />
            <input type = "submit" />
        </form>
    </body>
</html>