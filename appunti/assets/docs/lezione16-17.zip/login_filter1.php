<?php
        session_start();

        $conn = new PDO("pgsql:host=db;port=5432;dbname=postgres;user=postgres;password=postgres;");


        $username = $_GET["username"];
        $password = sha1($_GET["password"]."\n");

        //echo "username is: ".$username."<br />";

        $username = str_replace("OR", "", $username);

        //echo "username replaced is: ".$username."<br />";

        //echo "query: "."SELECT * FROM users WHERE username='$username' AND password='$password'"."<br />";


        // Query the database to check if the user exists
        $result = $conn->query("SELECT * FROM users WHERE username='$username' AND password='$password'");
        if (!$result) {
            echo "An error occurred.\n";
            exit;
        }

        try {
            $fresult = $result->fetchAll(PDO::FETCH_ASSOC);
            foreach ($fresult as &$value){
                echo "<h4>Welcome <b>".$value["username"]."</b></h4>";
                echo "<br/>";
            }
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }

        if ($user && password_verify($password, $user["password"])) {
            // Successful login
            $_SESSION["user_id"] = $user["id"];
            header("Location: welcome.php");
        } else {
            // Invalid credentials
            echo "Invalid username or password.";
        }
        
    ?>