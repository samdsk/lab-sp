<?php
    session_start();
    setcookie("login_id", "h39abcn5iah62f12h219s.47sb2", time() + 7 * 24 * 3600, "/");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Search Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 24px;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        #results {
            background-color: #f9f9f9;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .result {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Search Page</h1>

        
        <form action="xss.php" method="GET">
            <input type="text" name="search" id="search" placeholder="Search...">
            <input type="submit" value="Search">
        </form>

        <?php
            if(isset($_GET['search'])){
                echo "<h1>Results for ".$_GET['search']."</h1>";
            }
        ?>

        <div id="results">
            <!-- Search results will be displayed here -->
            <ul>
                <?php
                    $conn = new PDO("pgsql:host=db;port=5432;dbname=postgres;user=postgres;password=postgres;");
                    $search = $_GET["search"];

                    if(!isset($search) || $search == ""){
                        $sql = "SELECT productid,name,price FROM products";
                    }else{
                        $sql = "SELECT productid,name,price FROM products WHERE name='$search'";
                    }

                    //var_dump($sql);
                    $result = $conn->query($sql);
                    //var_dump($result);

                    try {
                        $fresult = $result->fetchAll(PDO::FETCH_ASSOC);
                        foreach ($fresult as &$value){
                            echo "<li>$".$value["price"]." - <b>".$value["name"]."</b> (<a href='".$value["url"]."'>link</a>)</li>";
                        }
                    } catch (PDOException $e) {
                        echo $e->getMessage();
                    }
                ?>
            </ul>
        </div>

    </div>

</body>
</html>
